var = input("Enter your name : ")
print (var)